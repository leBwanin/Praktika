﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Lopushok.Resources
{
    class Transition
    {
        public static Frame MainFrame { get; set; }
        public static object _DataContext { get; set; }
    }
}
